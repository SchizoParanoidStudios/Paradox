
package net.mcreator.paradox.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.paradox.init.ParadoxModItems;
import net.mcreator.paradox.init.ParadoxModFluids;
import net.mcreator.paradox.init.ParadoxModFluidTypes;
import net.mcreator.paradox.init.ParadoxModBlocks;

public abstract class StillWaterFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> ParadoxModFluidTypes.STILL_WATER_TYPE.get(), () -> ParadoxModFluids.STILL_WATER.get(), () -> ParadoxModFluids.FLOWING_STILL_WATER.get())
			.explosionResistance(100f).bucket(() -> ParadoxModItems.STILL_WATER_BUCKET.get()).block(() -> (LiquidBlock) ParadoxModBlocks.STILL_WATER.get());

	private StillWaterFluid() {
		super(PROPERTIES);
	}

	public static class Source extends StillWaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends StillWaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
