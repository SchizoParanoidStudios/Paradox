package net.mcreator.paradox.entity.model;

import software.bernie.geckolib.model.data.EntityModelData;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animatable.model.CoreGeoBone;
import software.bernie.geckolib.constant.DataTickets;

import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.entity.WorkerEntity;

public class WorkerModel extends GeoModel<WorkerEntity> {
	@Override
	public ResourceLocation getAnimationResource(WorkerEntity entity) {
		return new ResourceLocation("paradox", "animations/workerr.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(WorkerEntity entity) {
		return new ResourceLocation("paradox", "geo/workerr.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(WorkerEntity entity) {
		return new ResourceLocation("paradox", "textures/entities/" + entity.getTexture() + ".png");
	}

	@Override
	public void setCustomAnimations(WorkerEntity animatable, long instanceId, AnimationState animationState) {
		CoreGeoBone head = getAnimationProcessor().getBone("head");
		if (head != null) {
			EntityModelData entityData = (EntityModelData) animationState.getData(DataTickets.ENTITY_MODEL_DATA);
			head.setRotX(entityData.headPitch() * Mth.DEG_TO_RAD);
			head.setRotY(entityData.netHeadYaw() * Mth.DEG_TO_RAD);
		}

	}
}
