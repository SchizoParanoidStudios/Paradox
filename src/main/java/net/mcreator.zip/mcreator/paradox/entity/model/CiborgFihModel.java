package net.mcreator.paradox.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.entity.CiborgFihEntity;

public class CiborgFihModel extends GeoModel<CiborgFihEntity> {
	@Override
	public ResourceLocation getAnimationResource(CiborgFihEntity entity) {
		return new ResourceLocation("paradox", "animations/peskao.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(CiborgFihEntity entity) {
		return new ResourceLocation("paradox", "geo/peskao.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(CiborgFihEntity entity) {
		return new ResourceLocation("paradox", "textures/entities/" + entity.getTexture() + ".png");
	}

}
