package net.mcreator.paradox.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.entity.MutantBacterieEntity;

public class MutantBacterieModel extends GeoModel<MutantBacterieEntity> {
	@Override
	public ResourceLocation getAnimationResource(MutantBacterieEntity entity) {
		return new ResourceLocation("paradox", "animations/bacteri.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(MutantBacterieEntity entity) {
		return new ResourceLocation("paradox", "geo/bacteri.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(MutantBacterieEntity entity) {
		return new ResourceLocation("paradox", "textures/entities/" + entity.getTexture() + ".png");
	}

}
