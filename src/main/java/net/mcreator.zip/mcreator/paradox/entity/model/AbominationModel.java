package net.mcreator.paradox.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.entity.AbominationEntity;

public class AbominationModel extends GeoModel<AbominationEntity> {
	@Override
	public ResourceLocation getAnimationResource(AbominationEntity entity) {
		return new ResourceLocation("paradox", "animations/meat.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(AbominationEntity entity) {
		return new ResourceLocation("paradox", "geo/meat.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(AbominationEntity entity) {
		return new ResourceLocation("paradox", "textures/entities/" + entity.getTexture() + ".png");
	}

}
