package net.mcreator.paradox.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.entity.TimeBombEntityEntity;

public class TimeBombEntityModel extends GeoModel<TimeBombEntityEntity> {
	@Override
	public ResourceLocation getAnimationResource(TimeBombEntityEntity entity) {
		return new ResourceLocation("paradox", "animations/bomb.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(TimeBombEntityEntity entity) {
		return new ResourceLocation("paradox", "geo/bomb.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(TimeBombEntityEntity entity) {
		return new ResourceLocation("paradox", "textures/entities/" + entity.getTexture() + ".png");
	}

}
