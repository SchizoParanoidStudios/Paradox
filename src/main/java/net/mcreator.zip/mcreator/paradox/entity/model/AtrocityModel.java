package net.mcreator.paradox.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.entity.AtrocityEntity;

public class AtrocityModel extends GeoModel<AtrocityEntity> {
	@Override
	public ResourceLocation getAnimationResource(AtrocityEntity entity) {
		return new ResourceLocation("paradox", "animations/moste.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(AtrocityEntity entity) {
		return new ResourceLocation("paradox", "geo/moste.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(AtrocityEntity entity) {
		return new ResourceLocation("paradox", "textures/entities/" + entity.getTexture() + ".png");
	}

}
