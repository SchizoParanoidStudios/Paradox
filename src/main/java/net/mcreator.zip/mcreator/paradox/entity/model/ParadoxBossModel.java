package net.mcreator.paradox.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.entity.ParadoxBossEntity;

public class ParadoxBossModel extends GeoModel<ParadoxBossEntity> {
	@Override
	public ResourceLocation getAnimationResource(ParadoxBossEntity entity) {
		return new ResourceLocation("paradox", "animations/paradoxus.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(ParadoxBossEntity entity) {
		return new ResourceLocation("paradox", "geo/paradoxus.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(ParadoxBossEntity entity) {
		return new ResourceLocation("paradox", "textures/entities/" + entity.getTexture() + ".png");
	}

}
