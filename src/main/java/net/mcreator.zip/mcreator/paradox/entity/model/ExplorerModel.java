package net.mcreator.paradox.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.entity.ExplorerEntity;

public class ExplorerModel extends GeoModel<ExplorerEntity> {
	@Override
	public ResourceLocation getAnimationResource(ExplorerEntity entity) {
		return new ResourceLocation("paradox", "animations/explorerg.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(ExplorerEntity entity) {
		return new ResourceLocation("paradox", "geo/explorerg.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(ExplorerEntity entity) {
		return new ResourceLocation("paradox", "textures/entities/" + entity.getTexture() + ".png");
	}

}
