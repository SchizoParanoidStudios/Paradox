package net.mcreator.paradox.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.entity.SuitEntity;

public class SuitModel extends GeoModel<SuitEntity> {
	@Override
	public ResourceLocation getAnimationResource(SuitEntity entity) {
		return new ResourceLocation("paradox", "animations/ward.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SuitEntity entity) {
		return new ResourceLocation("paradox", "geo/ward.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SuitEntity entity) {
		return new ResourceLocation("paradox", "textures/entities/" + entity.getTexture() + ".png");
	}

}
