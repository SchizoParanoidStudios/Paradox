package net.mcreator.paradox.procedures;

import net.minecraft.world.entity.Entity;

public class TheLastInventor0OnEntityTickUpdateProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		ThelasttexgturProcedure.execute(entity);
	}
}
