package net.mcreator.paradox.procedures;

public class LaserGunRightclickedProcedure {
	public static void execute() {
	}
}
