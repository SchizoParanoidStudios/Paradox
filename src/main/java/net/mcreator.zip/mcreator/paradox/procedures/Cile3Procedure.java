package net.mcreator.paradox.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.particles.SimpleParticleType;

import net.mcreator.paradox.init.ParadoxModParticleTypes;

public class Cile3Procedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double xRadius = 0;
		double loop = 0;
		double zRadius = 0;
		double particleAmount = 0;
		loop = 0;
		particleAmount = 30;
		xRadius = 4;
		zRadius = 4;
		while (loop < particleAmount) {
			world.addParticle((SimpleParticleType) (ParadoxModParticleTypes.ELECTRICITY.get()), (x + 0.5 + Math.cos(((Math.PI * 2) / particleAmount) * loop) * xRadius), y, (z + 0.5 + Math.sin(((Math.PI * 2) / particleAmount) * loop) * zRadius), 0,
					0.05, 0);
			loop = loop + 1;
		}
	}
}
