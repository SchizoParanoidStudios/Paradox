package net.mcreator.paradox.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.paradox.init.ParadoxModEntities;
import net.mcreator.paradox.entity.ToxicologistEntity;
import net.mcreator.paradox.ParadoxMod;

public class EeeeeeeeeeeProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (Math.random() < 0.1) {
			if (!(((ToxicologistEntity) entity).animationprocedure).equals("mutan")) {
				if (entity instanceof ToxicologistEntity) {
					((ToxicologistEntity) entity).setAnimation("mutan");
				}
				ParadoxMod.queueServerWork(15, () -> {
					if (world instanceof ServerLevel _level) {
						Entity entityToSpawn = ParadoxModEntities.ATROCITY.get().spawn(_level, BlockPos.containing(entity.getX(), entity.getY() + 2.2, entity.getZ()), MobSpawnType.MOB_SUMMONED);
						if (entityToSpawn != null) {
							entityToSpawn.setDeltaMovement(0, 0.3, 0);
						}
					}
				});
			}
		}
	}
}
