package net.mcreator.paradox.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.paradox.init.ParadoxModEntities;
import net.mcreator.paradox.entity.ToxicologistEntity;
import net.mcreator.paradox.ParadoxMod;

public class ToxicologistEntityIsHurtProcedure {
	public static void execute(LevelAccessor world, DamageSource damagesource, Entity entity) {
		if (damagesource == null || entity == null)
			return;
		if (!damagesource.is(DamageTypes.WITHER)) {
			if (!damagesource.is(DamageTypes.INDIRECT_MAGIC)) {
				if (Math.random() < 0.1) {
					if (entity instanceof ToxicologistEntity) {
						((ToxicologistEntity) entity).setAnimation("mutan");
					}
					ParadoxMod.queueServerWork(15, () -> {
						if (world instanceof ServerLevel _level) {
							Entity entityToSpawn = ParadoxModEntities.ATROCITY.get().spawn(_level, BlockPos.containing(entity.getX(), entity.getY() + 2.2, entity.getZ()), MobSpawnType.MOB_SUMMONED);
							if (entityToSpawn != null) {
								entityToSpawn.setDeltaMovement(0, 0.3, 0);
							}
						}
					});
				}
			}
		}
	}
}
