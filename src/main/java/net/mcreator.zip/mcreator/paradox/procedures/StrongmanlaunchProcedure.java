package net.mcreator.paradox.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.core.registries.Registries;

import net.mcreator.paradox.entity.Strongman0Entity;
import net.mcreator.paradox.ParadoxMod;

import javax.annotation.Nullable;

import java.util.List;
import java.util.Comparator;

@Mod.EventBusSubscriber
public class StrongmanlaunchProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity(), event.getSource().getEntity());
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		execute(null, world, x, y, z, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (entity instanceof Strongman0Entity) {
			if (Math.random() > 0.3) {
				if (entity instanceof Strongman0Entity) {
					((Strongman0Entity) entity).setAnimation("empty");
				}
				if (entity instanceof Strongman0Entity) {
					((Strongman0Entity) entity).setAnimation("area");
				}
				ParadoxMod.queueServerWork(15, () -> {
					{
						final Vec3 _center = new Vec3(x, y, z);
						List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(5 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
						for (Entity entityiterator : _entfound) {
							if (entityiterator == sourceentity) {
								sourceentity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.MOB_ATTACK)), 2);
								if (entity.getX() > sourceentity.getX()) {
									entity.getPersistentData().putDouble("x1", (-0.5));
								}
								if (entity.getX() < sourceentity.getX()) {
									entity.getPersistentData().putDouble("x1", 0.5);
								}
								if (entity.getZ() < sourceentity.getZ()) {
									entity.getPersistentData().putDouble("z1", 0.5);
								}
								if (entity.getZ() > sourceentity.getZ()) {
									entity.getPersistentData().putDouble("z1", (-0.5));
								}
								sourceentity.setDeltaMovement(new Vec3((entity.getPersistentData().getDouble("x1")), 0.6, (entity.getPersistentData().getDouble("z1"))));
							}
						}
					}
				});
			}
		}
	}
}
