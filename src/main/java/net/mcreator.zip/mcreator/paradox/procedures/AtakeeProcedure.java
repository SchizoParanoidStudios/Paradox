package net.mcreator.paradox.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.core.registries.Registries;

import net.mcreator.paradox.entity.AbominationEntity;
import net.mcreator.paradox.ParadoxMod;

import javax.annotation.Nullable;

import java.util.List;
import java.util.Comparator;

@Mod.EventBusSubscriber
public class AtakeeProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity(), event.getSource().getEntity());
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		execute(null, world, x, y, z, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (sourceentity instanceof AbominationEntity) {
			if (event != null && event.isCancelable()) {
				event.setCanceled(true);
			} else if (event != null && event.hasResult()) {
				event.setResult(Event.Result.DENY);
			}
			if (Math.random() > 0.3) {
				if (sourceentity instanceof AbominationEntity) {
					((AbominationEntity) sourceentity).setAnimation("empty");
				}
				if (sourceentity instanceof AbominationEntity) {
					((AbominationEntity) sourceentity).setAnimation("atakee");
				}
				ParadoxMod.queueServerWork(15, () -> {
					{
						final Vec3 _center = new Vec3(x, y, z);
						List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(5 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
						for (Entity entityiterator : _entfound) {
							if (entityiterator == entity) {
								entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.MOB_ATTACK)), 8);
								if (sourceentity.getX() > entity.getX()) {
									sourceentity.getPersistentData().putDouble("x1", (-1));
								}
								if (sourceentity.getX() < entity.getX()) {
									sourceentity.getPersistentData().putDouble("x1", 1);
								}
								if (sourceentity.getZ() < entity.getZ()) {
									sourceentity.getPersistentData().putDouble("z1", 1);
								}
								if (sourceentity.getZ() > entity.getZ()) {
									sourceentity.getPersistentData().putDouble("z1", (-1));
								}
								entity.setDeltaMovement(new Vec3((sourceentity.getPersistentData().getDouble("x1")), 0, (sourceentity.getPersistentData().getDouble("z1"))));
							}
						}
					}
				});
			} else {
				if (sourceentity instanceof AbominationEntity) {
					((AbominationEntity) sourceentity).setAnimation("empty");
				}
				if (sourceentity instanceof AbominationEntity) {
					((AbominationEntity) sourceentity).setAnimation("smash");
				}
				ParadoxMod.queueServerWork(15, () -> {
					{
						final Vec3 _center = new Vec3(x, y, z);
						List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(7 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
						for (Entity entityiterator : _entfound) {
							if (!(entityiterator == sourceentity)) {
								if (sourceentity.getX() > entityiterator.getX()) {
									entityiterator.getPersistentData().putDouble("x1", (-0.5));
								}
								if (sourceentity.getX() < entityiterator.getX()) {
									entityiterator.getPersistentData().putDouble("x1", 0.5);
								}
								if (sourceentity.getZ() < entityiterator.getZ()) {
									entityiterator.getPersistentData().putDouble("z1", 0.5);
								}
								if (sourceentity.getZ() > entityiterator.getZ()) {
									entityiterator.getPersistentData().putDouble("z1", (-0.5));
								}
								entityiterator.setDeltaMovement(new Vec3((entityiterator.getPersistentData().getDouble("x1")), 0, (entityiterator.getPersistentData().getDouble("z1"))));
								entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.MOB_ATTACK)), 3);
							}
						}
					}
				});
			}
		}
	}
}
