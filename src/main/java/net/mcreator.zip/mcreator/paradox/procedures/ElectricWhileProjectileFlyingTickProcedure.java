package net.mcreator.paradox.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.particles.SimpleParticleType;

import net.mcreator.paradox.init.ParadoxModParticleTypes;

public class ElectricWhileProjectileFlyingTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		world.addParticle((SimpleParticleType) (ParadoxModParticleTypes.ELECTRICITY_2.get()), x, y, z, 0, 0, 0);
		world.addParticle((SimpleParticleType) (ParadoxModParticleTypes.ELECTRICITY_2.get()), x, y, z, 0, 0, 0);
		world.addParticle((SimpleParticleType) (ParadoxModParticleTypes.ELECTRICITY.get()), x, y, z, 0, 0, 0);
		world.addParticle((SimpleParticleType) (ParadoxModParticleTypes.ELECTRICITY.get()), x, y, z, 0, 0, 0);
	}
}
