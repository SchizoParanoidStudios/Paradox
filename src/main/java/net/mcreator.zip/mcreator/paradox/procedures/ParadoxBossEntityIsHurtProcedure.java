package net.mcreator.paradox.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;

import net.mcreator.paradox.init.ParadoxModParticleTypes;
import net.mcreator.paradox.init.ParadoxModEntities;
import net.mcreator.paradox.entity.ParadoxBossEntity;
import net.mcreator.paradox.ParadoxMod;

import java.util.List;
import java.util.Comparator;

public class ParadoxBossEntityIsHurtProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		double xRadius = 0;
		double loop = 0;
		double zRadius = 0;
		double particleAmount = 0;
		if (!(((ParadoxBossEntity) entity).animationprocedure).equals("deaty")) {
			if (entity.getPersistentData().getBoolean("tru") == true) {
				if (entity instanceof ParadoxBossEntity) {
					((ParadoxBossEntity) entity).setAnimation("rotasionjurt");
				}
			} else {
				if (entity instanceof ParadoxBossEntity) {
					((ParadoxBossEntity) entity).setAnimation("estaticjurt");
				}
			}
			if (entity.getPersistentData().getBoolean("tru") == true) {
				ParadoxMod.queueServerWork(15, () -> {
					if (Math.random() < 0.2) {
						if (Math.random() < 0.2) {
							if (entity instanceof ParadoxBossEntity) {
								((ParadoxBossEntity) entity).setAnimation("rotasionwisp");
							}
							{
								Entity _ent = entity;
								_ent.teleportTo((sourceentity.getX()), (sourceentity.getY()), (sourceentity.getZ()));
								if (_ent instanceof ServerPlayer _serverPlayer)
									_serverPlayer.connection.teleport((sourceentity.getX()), (sourceentity.getY()), (sourceentity.getZ()), _ent.getYRot(), _ent.getXRot());
							}
							ParadoxMod.queueServerWork(10, () -> {
								if (world instanceof Level _level && !_level.isClientSide())
									_level.explode(null, (sourceentity.getX()), (sourceentity.getY()), (sourceentity.getZ()), 2, Level.ExplosionInteraction.NONE);
							});
						}
						if (entity instanceof ParadoxBossEntity) {
							((ParadoxBossEntity) entity).setAnimation("rotasionwisp");
						}
						if (world instanceof ServerLevel _level) {
							Entity entityToSpawn = ParadoxModEntities.WISP.get().spawn(_level, BlockPos.containing(entity.getX(), y, entity.getZ()), MobSpawnType.MOB_SUMMONED);
							if (entityToSpawn != null) {
								entityToSpawn.setDeltaMovement(0, 0.4, 0);
							}
						}
					}
				});
			}
			if (Math.random() < 0.2) {
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(7 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (Entity entityiterator : _entfound) {
						if (entityiterator == sourceentity) {
							if (entity.getX() > entityiterator.getX()) {
								entity.getPersistentData().putDouble("x1", (-2));
							}
							if (entity.getX() < entityiterator.getX()) {
								entity.getPersistentData().putDouble("x1", 2);
							}
							if (entity.getZ() < entityiterator.getZ()) {
								entity.getPersistentData().putDouble("z1", 2);
							}
							if (entity.getZ() > entityiterator.getZ()) {
								entity.getPersistentData().putDouble("z1", (-2));
							}
							entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.LIGHTNING_BOLT)), 3);
							entityiterator.setDeltaMovement(new Vec3((entity.getPersistentData().getDouble("x1")), 0.5, (entity.getPersistentData().getDouble("z1"))));
							loop = 0;
							particleAmount = 60;
							xRadius = 9;
							zRadius = 9;
							while (loop < particleAmount) {
								world.addParticle((SimpleParticleType) (ParadoxModParticleTypes.ELECTRICITY_2.get()), (x + 0.5 + Math.cos(((Math.PI * 2) / particleAmount) * loop) * xRadius), y,
										(z + 0.5 + Math.sin(((Math.PI * 2) / particleAmount) * loop) * zRadius), 0, 0.05, 0);
								if (entity.getPersistentData().getBoolean("tru") == true) {
									if (entity instanceof ParadoxBossEntity) {
										((ParadoxBossEntity) entity).setAnimation("rotasionwisp");
									}
								} else {
									if (entity instanceof ParadoxBossEntity) {
										((ParadoxBossEntity) entity).setAnimation("estaticshok");
									}
								}
								loop = loop + 1;
							}
						}
					}
				}
			}
		}
		if (world instanceof ServerLevel _level)
			_level.sendParticles((SimpleParticleType) (ParadoxModParticleTypes.ELECTRICITY.get()), x, y, z, 5, 0.1, 0.1, 0.1, 0.1);
	}
}
