package net.mcreator.paradox.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;

import net.mcreator.paradox.init.ParadoxModParticleTypes;
import net.mcreator.paradox.ParadoxMod;

public class IncursorOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < 5) {
			ParadoxMod.queueServerWork(100, () -> {
				if (entity.isAlive()) {
					if (world instanceof ServerLevel _level)
						_level.sendParticles((SimpleParticleType) (ParadoxModParticleTypes.ELECTRICITY_2.get()), x, (y + 1.5), z, 15, 0.1, 0.1, 0.1, 0.1);
					if (!entity.level().isClientSide())
						entity.discard();
					if (world instanceof Level _level && !_level.isClientSide())
						_level.explode(null, x, y, z, 1, Level.ExplosionInteraction.NONE);
				}
			});
			if (Math.random() < 0.5) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ParadoxModParticleTypes.ELECTRICITY.get()), x, (y + 1.5), z, 5, 0.1, 0.1, 0.1, 0.1);
			}
		}
	}
}
