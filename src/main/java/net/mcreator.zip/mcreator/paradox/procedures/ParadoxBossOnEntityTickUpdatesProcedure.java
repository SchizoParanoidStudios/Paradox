package net.mcreator.paradox.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.paradox.init.ParadoxModParticleTypes;
import net.mcreator.paradox.entity.ParadoxBossEntity;

public class ParadoxBossOnEntityTickUpdatesProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getBoolean("tru") == false) {
			entity.setDeltaMovement(new Vec3(0, 0, 0));
		} else {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ParadoxModParticleTypes.ELECTRICITY_2.get()), x, y, z, 5, 0.5, 0.5, 0.5, 0.5);
			if (Math.random() < 0.1) {
				entity.push(0, (-0.05), 0);
			}
			if (Math.random() < 0.1) {
				entity.push(0, 0, (-0.05));
			}
			if (Math.random() < 0.1) {
				entity.push(0, 0, 0.05);
			}
			if (Math.random() < 0.1) {
				entity.push((-0.05), 0, 0);
			}
			if (Math.random() < 0.1) {
				entity.push(0.05, 0, 0);
			}
		}
		if (entity.getPersistentData().getBoolean("tru") == false) {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < 180) {
				entity.getPersistentData().putBoolean("tru", true);
				if (entity instanceof ParadoxBossEntity) {
					((ParadoxBossEntity) entity).setAnimation("rotasion");
				}
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:paradox")), SoundSource.MUSIC, 1, 1);
					} else {
						_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:paradox")), SoundSource.MUSIC, 1, 1, false);
					}
				}
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"/stopsound paradox:industrial");
			}
		}
		if (!(((ParadoxBossEntity) entity).animationprocedure).equals("rotasion") && !(((ParadoxBossEntity) entity).animationprocedure).equals("rotasionwisp") && !(((ParadoxBossEntity) entity).animationprocedure).equals("deaty")
				&& !(((ParadoxBossEntity) entity).animationprocedure).equals("rotasionjurt")) {
			if (entity.getPersistentData().getBoolean("tru") == true) {
				if (entity instanceof ParadoxBossEntity) {
					((ParadoxBossEntity) entity).setAnimation("rotasion");
				}
			}
		}
	}
}
