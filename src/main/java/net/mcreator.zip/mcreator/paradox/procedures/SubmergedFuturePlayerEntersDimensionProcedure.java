package net.mcreator.paradox.procedures;

import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.paradox.network.ParadoxModVariables;

public class SubmergedFuturePlayerEntersDimensionProcedure {
	public static void execute(LevelAccessor world, double x, double z, Entity entity) {
		if (entity == null)
			return;
		if (ParadoxModVariables.MapVariables.get(world).abierto == false) {
			ParadoxModVariables.MapVariables.get(world).abierto = true;
			ParadoxModVariables.MapVariables.get(world).syncData(world);
			if (world instanceof ServerLevel _serverworld) {
				StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("paradox", "test3"));
				if (template != null) {
					template.placeInWorld(_serverworld, BlockPos.containing(x - 39, 36, z - 49), BlockPos.containing(x - 39, 36, z - 49), new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false),
							_serverworld.random, 3);
				}
			}
			ParadoxModVariables.MapVariables.get(world).dimension_x = x;
			ParadoxModVariables.MapVariables.get(world).syncData(world);
			ParadoxModVariables.MapVariables.get(world).dimensin_y = 139;
			ParadoxModVariables.MapVariables.get(world).syncData(world);
			ParadoxModVariables.MapVariables.get(world).dimension_z = z;
			ParadoxModVariables.MapVariables.get(world).syncData(world);
		}
		if ((entity.getCapability(ParadoxModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParadoxModVariables.PlayerVariables())).entrado == true) {
			{
				Entity _ent = entity;
				_ent.teleportTo(((entity.getCapability(ParadoxModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParadoxModVariables.PlayerVariables())).cloc_x),
						((entity.getCapability(ParadoxModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParadoxModVariables.PlayerVariables())).clocl_y),
						((entity.getCapability(ParadoxModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParadoxModVariables.PlayerVariables())).clocl_z));
				if (_ent instanceof ServerPlayer _serverPlayer)
					_serverPlayer.connection.teleport(((entity.getCapability(ParadoxModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParadoxModVariables.PlayerVariables())).cloc_x),
							((entity.getCapability(ParadoxModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParadoxModVariables.PlayerVariables())).clocl_y),
							((entity.getCapability(ParadoxModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParadoxModVariables.PlayerVariables())).clocl_z), _ent.getYRot(), _ent.getXRot());
			}
		}
		if ((entity.getCapability(ParadoxModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ParadoxModVariables.PlayerVariables())).entrado == false) {
			{
				Entity _ent = entity;
				_ent.teleportTo(ParadoxModVariables.MapVariables.get(world).dimension_x, 139, ParadoxModVariables.MapVariables.get(world).dimension_z);
				if (_ent instanceof ServerPlayer _serverPlayer)
					_serverPlayer.connection.teleport(ParadoxModVariables.MapVariables.get(world).dimension_x, 139, ParadoxModVariables.MapVariables.get(world).dimension_z, _ent.getYRot(), _ent.getXRot());
			}
			{
				boolean _setval = true;
				entity.getCapability(ParadoxModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.entrado = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = z;
				entity.getCapability(ParadoxModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.clocl_z = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = 139;
				entity.getCapability(ParadoxModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.clocl_y = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = x;
				entity.getCapability(ParadoxModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.cloc_x = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}
