package net.mcreator.paradox.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;

import net.mcreator.paradox.init.ParadoxModParticleTypes;
import net.mcreator.paradox.ParadoxMod;

import java.util.List;
import java.util.Comparator;

public class ShcpProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		double xRadius = 0;
		double loop = 0;
		double zRadius = 0;
		double particleAmount = 0;
		loop = 0;
		particleAmount = 30;
		xRadius = 7;
		zRadius = 7;
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 300, 1, false, false));
		while (loop < particleAmount) {
			world.addParticle((SimpleParticleType) (ParadoxModParticleTypes.ELECTRICITY.get()), (x + 0.5 + Math.cos(((Math.PI * 2) / particleAmount) * loop) * xRadius), y, (z + 0.5 + Math.sin(((Math.PI * 2) / particleAmount) * loop) * zRadius), 0,
					0.05, 0);
			loop = loop + 1;
		}
		{
			final Vec3 _center = new Vec3(x, y, z);
			List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(7 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
			for (Entity entityiterator : _entfound) {
				if (entityiterator == sourceentity) {
					if (entity.getX() > entityiterator.getX()) {
						entity.getPersistentData().putDouble("x1", (-0.5));
					}
					if (entity.getX() < entityiterator.getX()) {
						entity.getPersistentData().putDouble("x1", 0.5);
					}
					if (entity.getZ() < entityiterator.getZ()) {
						entity.getPersistentData().putDouble("z1", 0.5);
					}
					if (entity.getZ() > entityiterator.getZ()) {
						entity.getPersistentData().putDouble("z1", (-0.5));
					}
					entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.LIGHTNING_BOLT)), 1);
					ParadoxMod.queueServerWork(10, () -> {
						entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.LIGHTNING_BOLT)), 1);
						ParadoxMod.queueServerWork(10, () -> {
							entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.LIGHTNING_BOLT)), 1);
						});
					});
					entityiterator.setDeltaMovement(new Vec3((entity.getPersistentData().getDouble("x1")), 0, (entity.getPersistentData().getDouble("z1"))));
				}
			}
		}
	}
}
