package net.mcreator.paradox.procedures;

import net.minecraft.world.item.ItemStack;

import net.mcreator.paradox.item.ElectricStaffItem;

public class VarahandProcedure {
	public static void execute(ItemStack itemstack) {
		if (itemstack.getOrCreateTag().getDouble("energy") > 0) {
			if (!(((ElectricStaffItem) itemstack.getItem()).animationprocedure).equals("electrico")) {
				if (itemstack.getItem() instanceof ElectricStaffItem)
					itemstack.getOrCreateTag().putString("geckoAnim", "electrico");
			}
		}
	}
}
