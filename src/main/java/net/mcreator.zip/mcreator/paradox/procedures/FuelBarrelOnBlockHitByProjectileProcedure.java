package net.mcreator.paradox.procedures;

public class FuelBarrelOnBlockHitByProjectileProcedure {
	public static void execute() {
	}
}
