package net.mcreator.paradox.procedures;

public class ChargerOnBlockRightClickedProcedure {
	public static void execute() {
	}
}
