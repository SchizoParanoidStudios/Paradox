package net.mcreator.paradox.procedures;

public class ParadoxBossOnEntityTickUpdateProcedure {
	public static void execute() {
	}
}
