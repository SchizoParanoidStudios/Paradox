package net.mcreator.paradox.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.paradox.entity.TheLastInventor0Entity;

public class ThelasttexgturProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (!(((TheLastInventor0Entity) entity).animationprocedure).equals("electric")) {
			if (entity instanceof TheLastInventor0Entity animatable)
				animatable.setTexture("makiineee");
		}
		if ((((TheLastInventor0Entity) entity).animationprocedure).equals("electric")) {
			if (entity instanceof TheLastInventor0Entity animatable)
				animatable.setTexture("viejo3");
		}
	}
}
