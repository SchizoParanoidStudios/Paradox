package net.mcreator.paradox.procedures;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.paradox.entity.WorkerEntity;
import net.mcreator.paradox.entity.ToxicologistEntity;
import net.mcreator.paradox.entity.TheLastInventor0Entity;
import net.mcreator.paradox.entity.SuitEntity;
import net.mcreator.paradox.entity.Strongman0Entity;
import net.mcreator.paradox.entity.ForemanEntity;
import net.mcreator.paradox.entity.ExplorerEntity;
import net.mcreator.paradox.entity.AtrocityEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class SoundProcedure {
	@SubscribeEvent
	public static void onEntityTick(LivingEvent.LivingTickEvent event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (Math.random() < 0.1) {
			if (Math.random() < 0.2) {
				if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 14, 14, 14), e -> true).isEmpty()) {
					if (entity instanceof TheLastInventor0Entity) {
						if (Math.random() < 0.5) {
							if (world instanceof Level _level) {
								if (!_level.isClientSide()) {
									_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:inventor_voice1")), SoundSource.VOICE, 1, 1);
								} else {
									_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:inventor_voice1")), SoundSource.VOICE, 1, 1, false);
								}
							}
						} else {
							if (Math.random() < 0.5) {
								if (world instanceof Level _level) {
									if (!_level.isClientSide()) {
										_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:inventor_voice2")), SoundSource.VOICE, 1, 1);
									} else {
										_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:inventor_voice2")), SoundSource.VOICE, 1, 1, false);
									}
								}
							} else {
								if (world instanceof Level _level) {
									if (!_level.isClientSide()) {
										_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:inventor_voice3")), SoundSource.VOICE, 1, 1);
									} else {
										_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:inventor_voice3")), SoundSource.VOICE, 1, 1, false);
									}
								}
							}
						}
					}
					if (entity instanceof ToxicologistEntity) {
						if (Math.random() < 0.5) {
							if (world instanceof Level _level) {
								if (!_level.isClientSide()) {
									_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:toxic_voice2")), SoundSource.VOICE, 1, 1);
								} else {
									_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:toxic_voice2")), SoundSource.VOICE, 1, 1, false);
								}
							}
						}
					}
					if (entity instanceof AtrocityEntity) {
						if (Math.random() < 0.5) {
							if (world instanceof Level _level) {
								if (!_level.isClientSide()) {
									_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:atrocity_voice2")), SoundSource.VOICE, 1, 1);
								} else {
									_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:atrocity_voice2")), SoundSource.VOICE, 1, 1, false);
								}
							}
						} else {
							if (world instanceof Level _level) {
								if (!_level.isClientSide()) {
									_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:atrcoity_voice_1")), SoundSource.VOICE, 1, 1);
								} else {
									_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:atrcoity_voice_1")), SoundSource.VOICE, 1, 1, false);
								}
							}
						}
					}
					if (entity instanceof ExplorerEntity) {
						if (Math.random() < 0.5) {
							if (world instanceof Level _level) {
								if (!_level.isClientSide()) {
									_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:heli_voice")), SoundSource.VOICE, 1, 1);
								} else {
									_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:heli_voice")), SoundSource.VOICE, 1, 1, false);
								}
							}
						}
					}
					if (entity instanceof SuitEntity) {
						if (Math.random() < 0.5) {
							if (world instanceof Level _level) {
								if (!_level.isClientSide()) {
									_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:inspector_voice1")), SoundSource.VOICE, 1, 1);
								} else {
									_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:inspector_voice1")), SoundSource.VOICE, 1, 1, false);
								}
							}
						} else {
							if (world instanceof Level _level) {
								if (!_level.isClientSide()) {
									_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:inspectro_voice")), SoundSource.VOICE, 1, 1);
								} else {
									_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:inspectro_voice")), SoundSource.VOICE, 1, 1, false);
								}
							}
						}
					}
					if (entity instanceof WorkerEntity || entity instanceof ForemanEntity) {
						if (Math.random() < 0.5) {
							if (Math.random() < 0.5) {
								if (world instanceof Level _level) {
									if (!_level.isClientSide()) {
										_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:welder_voice")), SoundSource.VOICE, 1, 1);
									} else {
										_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:welder_voice")), SoundSource.VOICE, 1, 1, false);
									}
								}
							} else {
								if (world instanceof Level _level) {
									if (!_level.isClientSide()) {
										_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:worker_idle2")), SoundSource.VOICE, 1, 1);
									} else {
										_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:worker_idle2")), SoundSource.VOICE, 1, 1, false);
									}
								}
							}
						} else {
							if (world instanceof Level _level) {
								if (!_level.isClientSide()) {
									_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:worker_idle2")), SoundSource.VOICE, 1, 1);
								} else {
									_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:worker_idle2")), SoundSource.VOICE, 1, 1, false);
								}
							}
						}
					}
					if (entity instanceof Strongman0Entity) {
						if (Math.random() < 0.5) {
							if (Math.random() < 0.5) {
								if (world instanceof Level _level) {
									if (!_level.isClientSide()) {
										_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:strongman_voice2")), SoundSource.VOICE, 1, 1);
									} else {
										_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:strongman_voice2")), SoundSource.VOICE, 1, 1, false);
									}
								}
							} else {
								if (world instanceof Level _level) {
									if (!_level.isClientSide()) {
										_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:strongman_voice3")), SoundSource.VOICE, 1, 1);
									} else {
										_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:strongman_voice3")), SoundSource.VOICE, 1, 1, false);
									}
								}
							}
						} else {
							if (world instanceof Level _level) {
								if (!_level.isClientSide()) {
									_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:strongman_voice1")), SoundSource.VOICE, 1, 1);
								} else {
									_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("paradox:strongman_voice1")), SoundSource.VOICE, 1, 1, false);
								}
							}
						}
					}
				}
			}
		}
	}
}
