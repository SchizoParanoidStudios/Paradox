package net.mcreator.paradox.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;

public class ActivarsierraProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (itemstack.getOrCreateTag().getBoolean("activaded") == false) {
			itemstack.getOrCreateTag().putBoolean("activaded", true);
			itemstack.getOrCreateTag().putDouble("energy", 20);
		}
		SawingProcedure.execute(world, x, y, z, entity, itemstack);
	}
}
