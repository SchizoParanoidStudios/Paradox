package net.mcreator.paradox.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.registries.Registries;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.client.Minecraft;

import net.mcreator.paradox.entity.Strongman0Entity;
import net.mcreator.paradox.ParadoxMod;

import java.util.List;
import java.util.Comparator;

public class StrongmanOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (Math.random() < 0.5) {
			if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 5, 5, 5), e -> true).isEmpty())) {
				if (!(((Strongman0Entity) entity).animationprocedure).equals("pu\u00F1ito")) {
					if (entity instanceof LivingEntity _livEnt2 && _livEnt2.hasEffect(MobEffects.LUCK)) {
						{
							final Vec3 _center = new Vec3(x, y, z);
							List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(9 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
							for (Entity entityiterator : _entfound) {
								if (entityiterator instanceof Player) {
									if (!(new Object() {
										public boolean checkGamemode(Entity _ent) {
											if (_ent instanceof ServerPlayer _serverPlayer) {
												return _serverPlayer.gameMode.getGameModeForPlayer() == GameType.CREATIVE;
											} else if (_ent.level().isClientSide() && _ent instanceof Player _player) {
												return Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()) != null
														&& Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()).getGameMode() == GameType.CREATIVE;
											}
											return false;
										}
									}.checkGamemode(entityiterator))) {
										if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
											_entity.addEffect(new MobEffectInstance(MobEffects.LUCK, 300, 1, false, false));
										if (entity instanceof Strongman0Entity) {
											((Strongman0Entity) entity).setAnimation("golpe");
										}
										entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entityiterator.getX()), y, (entityiterator.getZ())));
										ParadoxMod.queueServerWork(10, () -> {
											entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.MOB_ATTACK)), 12);
											entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entityiterator.getX()), y, (entityiterator.getZ())));
											if (entity.getX() > entityiterator.getX()) {
												entity.getPersistentData().putDouble("x1", (-1));
											}
											if (entity.getX() < entityiterator.getX()) {
												entity.getPersistentData().putDouble("x1", 1);
											}
											if (entity.getZ() < entityiterator.getZ()) {
												entity.getPersistentData().putDouble("z1", 1);
											}
											if (entity.getZ() > entityiterator.getZ()) {
												entity.getPersistentData().putDouble("z1", (-1));
											}
											entityiterator.setDeltaMovement(new Vec3((entity.getPersistentData().getDouble("x1")), 0, (entity.getPersistentData().getDouble("z1"))));
										});
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
