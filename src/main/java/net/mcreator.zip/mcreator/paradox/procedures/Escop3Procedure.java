package net.mcreator.paradox.procedures;

public class Escop3Procedure {
	public static void execute() {
	}
}
