package net.mcreator.paradox.procedures;

import net.minecraft.world.item.ItemStack;

public class Activ2Procedure {
	public static void execute(ItemStack itemstack) {
		if (itemstack.getOrCreateTag().getBoolean("activaded") == false) {
			itemstack.getOrCreateTag().putBoolean("activaded", true);
			itemstack.getOrCreateTag().putDouble("energy", 20);
		}
	}
}
