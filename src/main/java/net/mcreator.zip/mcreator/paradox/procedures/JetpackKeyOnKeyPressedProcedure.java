package net.mcreator.paradox.procedures;

import top.theillusivec4.curios.api.CuriosApi;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.paradox.init.ParadoxModItems;

public class JetpackKeyOnKeyPressedProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity lv ? CuriosApi.getCuriosHelper().findEquippedCurio(ParadoxModItems.JETPACK.get(), lv).isPresent() : false) {
			if (!(entity instanceof Player _plrCldCheck1 && _plrCldCheck1.getCooldowns().isOnCooldown(ParadoxModItems.JETPACK.get()))) {
				if (entity.isShiftKeyDown()) {
					entity.setDeltaMovement(new Vec3(0, 1, 0));
					if (entity instanceof Player _player)
						_player.getCooldowns().addCooldown(ParadoxModItems.JETPACK.get(), 100);
				} else {
					if (entity instanceof Player _player)
						_player.getCooldowns().addCooldown(ParadoxModItems.JETPACK.get(), 100);
					entity.push((entity.getLookAngle().x * 2.2), (entity.getLookAngle().y * 1.3), (entity.getLookAngle().z * 2.2));
				}
			}
		}
	}
}
