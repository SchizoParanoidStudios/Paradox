package net.mcreator.paradox.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

public class BronzePipeLivingEntityIsHitWithToolProcedure {
	public static void execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
		if (sourceentity.getX() > entity.getX()) {
			sourceentity.getPersistentData().putDouble("x1", (-1));
		}
		if (sourceentity.getX() < entity.getX()) {
			sourceentity.getPersistentData().putDouble("x1", 1);
		}
		if (sourceentity.getZ() < entity.getZ()) {
			sourceentity.getPersistentData().putDouble("z1", 1);
		}
		if (sourceentity.getZ() > entity.getZ()) {
			sourceentity.getPersistentData().putDouble("z1", (-1));
		}
		entity.setDeltaMovement(new Vec3((sourceentity.getPersistentData().getDouble("x1")), 0, (sourceentity.getPersistentData().getDouble("z1"))));
	}
}
