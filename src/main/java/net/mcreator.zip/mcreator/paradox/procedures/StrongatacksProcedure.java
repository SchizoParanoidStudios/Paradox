package net.mcreator.paradox.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.core.registries.Registries;
import net.minecraft.commands.arguments.EntityAnchorArgument;

import net.mcreator.paradox.entity.Strongman0Entity;
import net.mcreator.paradox.ParadoxMod;

import javax.annotation.Nullable;

import java.util.List;
import java.util.Comparator;

@Mod.EventBusSubscriber
public class StrongatacksProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity(), event.getSource().getEntity());
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		execute(null, world, x, y, z, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (sourceentity instanceof Strongman0Entity) {
			if (event != null && event.isCancelable()) {
				event.setCanceled(true);
			} else if (event != null && event.hasResult()) {
				event.setResult(Event.Result.DENY);
			}
			if (sourceentity instanceof Strongman0Entity) {
				((Strongman0Entity) sourceentity).setAnimation("pu\u00F1ito");
			}
			sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), y, (entity.getZ())));
			if (sourceentity instanceof Mob _entity)
				_entity.getNavigation().moveTo((entity.getX()), (entity.getY()), (entity.getZ()), 2);
			ParadoxMod.queueServerWork(10, () -> {
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(5 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (Entity entityiterator : _entfound) {
						if (entityiterator == entity) {
							entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.MOB_ATTACK)), 7);
							sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), y, (entity.getZ())));
							if (sourceentity.getX() > entity.getX()) {
								sourceentity.getPersistentData().putDouble("x1", (-0.5));
							}
							if (sourceentity.getX() < entity.getX()) {
								sourceentity.getPersistentData().putDouble("x1", 0.5);
							}
							if (sourceentity.getZ() < entity.getZ()) {
								sourceentity.getPersistentData().putDouble("z1", 0.5);
							}
							if (sourceentity.getZ() > entity.getZ()) {
								sourceentity.getPersistentData().putDouble("z1", (-0.5));
							}
							entity.setDeltaMovement(new Vec3((sourceentity.getPersistentData().getDouble("x1")), 0, (sourceentity.getPersistentData().getDouble("z1"))));
						}
					}
				}
			});
		}
	}
}
