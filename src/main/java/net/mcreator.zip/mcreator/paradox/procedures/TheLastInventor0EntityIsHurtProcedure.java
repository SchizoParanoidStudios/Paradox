package net.mcreator.paradox.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

import net.mcreator.paradox.init.ParadoxModEntities;
import net.mcreator.paradox.entity.TheLastInventor0Entity;
import net.mcreator.paradox.ParadoxMod;

public class TheLastInventor0EntityIsHurtProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (Math.random() < 0.4) {
			if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 7, 7, 7), e -> true).isEmpty()) {
				if (Math.random() < 0.5) {
					if (entity instanceof TheLastInventor0Entity) {
						((TheLastInventor0Entity) entity).setAnimation("electric");
					}
					ShcpProcedure.execute(world, x, y, z, entity, sourceentity);
				} else {
					if (entity instanceof TheLastInventor0Entity) {
						((TheLastInventor0Entity) entity).setAnimation("launch");
					}
					ParadoxMod.queueServerWork(10, () -> {
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.SMOKE, x, (y + 2), z, 20, 0.1, 0.1, 0.1, 0.1);
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 10, 0.2, 0.2, 0.2, 0.2);
						if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 150, 0));
					});
				}
			} else {
				if (Math.random() < 0.5) {
					if (entity instanceof TheLastInventor0Entity) {
						((TheLastInventor0Entity) entity).setAnimation("launch");
					}
					if (world instanceof ServerLevel _level) {
						Entity entityToSpawn = ParadoxModEntities.EXPLORER.get().spawn(_level, BlockPos.containing(entity.getX(), y + 3, entity.getZ()), MobSpawnType.MOB_SUMMONED);
						if (entityToSpawn != null) {
							entityToSpawn.setDeltaMovement(0, 0.5, 0);
						}
					}
				} else {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 150, 1, false, false));
				}
			}
		}
	}
}
