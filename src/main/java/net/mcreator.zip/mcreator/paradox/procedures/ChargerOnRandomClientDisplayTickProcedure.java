package net.mcreator.paradox.procedures;

public class ChargerOnRandomClientDisplayTickProcedure {
	public static void execute() {
	}
}
