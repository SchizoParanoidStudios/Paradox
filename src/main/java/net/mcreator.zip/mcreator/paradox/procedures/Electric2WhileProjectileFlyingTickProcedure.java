package net.mcreator.paradox.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;

import net.mcreator.paradox.init.ParadoxModParticleTypes;

public class Electric2WhileProjectileFlyingTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world instanceof ServerLevel _level)
			_level.sendParticles((SimpleParticleType) (ParadoxModParticleTypes.ELECTRICITY_2.get()), x, y, z, 5, 0, 0, 0, 0.1);
	}
}
