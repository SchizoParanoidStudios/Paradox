package net.mcreator.paradox.procedures;

import net.minecraft.world.item.ItemStack;

public class DinamiteRangedItemShootsProjectileProcedure {
	public static void execute(ItemStack itemstack) {
		itemstack.shrink(1);
	}
}
