package net.mcreator.paradox.procedures;

public class ConditioneProcedure {
	public static boolean execute() {
		return Math.random() < 0.1;
	}
}
