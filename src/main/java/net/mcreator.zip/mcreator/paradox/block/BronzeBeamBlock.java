
package net.mcreator.paradox.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.FaceAttachedHorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class BronzeBeamBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
	public static final EnumProperty<AttachFace> FACE = FaceAttachedHorizontalDirectionalBlock.FACE;

	public BronzeBeamBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.COPPER).strength(3f, 15f).requiresCorrectToolForDrops().noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(FACE, AttachFace.WALL));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(13, 0, 2, 15, 16, 14), box(3, 0, 7, 13, 16, 9), box(1, 0, 2, 3, 16, 14));
				case WALL -> Shapes.or(box(13, 2, 0, 15, 14, 16), box(3, 7, 0, 13, 9, 16), box(1, 2, 0, 3, 14, 16));
				case CEILING -> Shapes.or(box(1, 0, 2, 3, 16, 14), box(3, 0, 7, 13, 16, 9), box(13, 0, 2, 15, 16, 14));
			};
			case NORTH -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(1, 0, 2, 3, 16, 14), box(3, 0, 7, 13, 16, 9), box(13, 0, 2, 15, 16, 14));
				case WALL -> Shapes.or(box(1, 2, 0, 3, 14, 16), box(3, 7, 0, 13, 9, 16), box(13, 2, 0, 15, 14, 16));
				case CEILING -> Shapes.or(box(13, 0, 2, 15, 16, 14), box(3, 0, 7, 13, 16, 9), box(1, 0, 2, 3, 16, 14));
			};
			case EAST -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(2, 0, 1, 14, 16, 3), box(7, 0, 3, 9, 16, 13), box(2, 0, 13, 14, 16, 15));
				case WALL -> Shapes.or(box(0, 2, 1, 16, 14, 3), box(0, 7, 3, 16, 9, 13), box(0, 2, 13, 16, 14, 15));
				case CEILING -> Shapes.or(box(2, 0, 13, 14, 16, 15), box(7, 0, 3, 9, 16, 13), box(2, 0, 1, 14, 16, 3));
			};
			case WEST -> switch (state.getValue(FACE)) {
				case FLOOR -> Shapes.or(box(2, 0, 13, 14, 16, 15), box(7, 0, 3, 9, 16, 13), box(2, 0, 1, 14, 16, 3));
				case WALL -> Shapes.or(box(0, 2, 13, 16, 14, 15), box(0, 7, 3, 16, 9, 13), box(0, 2, 1, 16, 14, 3));
				case CEILING -> Shapes.or(box(2, 0, 1, 14, 16, 3), box(7, 0, 3, 9, 16, 13), box(2, 0, 13, 14, 16, 15));
			};
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING, FACE);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(FACE, faceForDirection(context.getNearestLookingDirection())).setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	private AttachFace faceForDirection(Direction direction) {
		if (direction.getAxis() == Direction.Axis.Y)
			return direction == Direction.UP ? AttachFace.CEILING : AttachFace.FLOOR;
		else
			return AttachFace.WALL;
	}
}
