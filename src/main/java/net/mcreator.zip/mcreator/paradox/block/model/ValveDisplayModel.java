package net.mcreator.paradox.block.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.block.display.ValveDisplayItem;

public class ValveDisplayModel extends GeoModel<ValveDisplayItem> {
	@Override
	public ResourceLocation getAnimationResource(ValveDisplayItem animatable) {
		return new ResourceLocation("paradox", "animations/valvulaanimada.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(ValveDisplayItem animatable) {
		return new ResourceLocation("paradox", "geo/valvulaanimada.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(ValveDisplayItem entity) {
		return new ResourceLocation("paradox", "textures/block/puertaproo.png");
	}
}
