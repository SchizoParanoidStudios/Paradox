
package net.mcreator.paradox.block;

import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.SoundType;

public class BronzeVentBlock extends TrapDoorBlock {
	public BronzeVentBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.COPPER).strength(3f, 15f).requiresCorrectToolForDrops(), BlockSetType.STONE);
	}
}
