
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.paradox.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.paradox.fluid.StillWaterFluid;
import net.mcreator.paradox.fluid.HotWaterFluid;
import net.mcreator.paradox.fluid.ContaminatedWaterFluid;
import net.mcreator.paradox.fluid.AcidFluid;
import net.mcreator.paradox.ParadoxMod;

public class ParadoxModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, ParadoxMod.MODID);
	public static final RegistryObject<FlowingFluid> CONTAMINATED_WATER = REGISTRY.register("contaminated_water", () -> new ContaminatedWaterFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_CONTAMINATED_WATER = REGISTRY.register("flowing_contaminated_water", () -> new ContaminatedWaterFluid.Flowing());
	public static final RegistryObject<FlowingFluid> STILL_WATER = REGISTRY.register("still_water", () -> new StillWaterFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_STILL_WATER = REGISTRY.register("flowing_still_water", () -> new StillWaterFluid.Flowing());
	public static final RegistryObject<FlowingFluid> HOT_WATER = REGISTRY.register("hot_water", () -> new HotWaterFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_HOT_WATER = REGISTRY.register("flowing_hot_water", () -> new HotWaterFluid.Flowing());
	public static final RegistryObject<FlowingFluid> ACID = REGISTRY.register("acid", () -> new AcidFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_ACID = REGISTRY.register("flowing_acid", () -> new AcidFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(CONTAMINATED_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_CONTAMINATED_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(STILL_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_STILL_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(HOT_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_HOT_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(ACID.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_ACID.get(), RenderType.translucent());
		}
	}
}
