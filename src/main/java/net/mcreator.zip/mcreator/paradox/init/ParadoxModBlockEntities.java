
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.paradox.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.mcreator.paradox.block.entity.ValveTileEntity;
import net.mcreator.paradox.block.entity.FilingCabinetBlockEntity;
import net.mcreator.paradox.block.entity.BronzeFilingCabinetBlockEntity;
import net.mcreator.paradox.ParadoxMod;

public class ParadoxModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, ParadoxMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> BRONZE_FILING_CABINET = register("bronze_filing_cabinet", ParadoxModBlocks.BRONZE_FILING_CABINET, BronzeFilingCabinetBlockEntity::new);
	public static final RegistryObject<BlockEntityType<ValveTileEntity>> VALVE = REGISTRY.register("valve", () -> BlockEntityType.Builder.of(ValveTileEntity::new, ParadoxModBlocks.VALVE.get()).build(null));
	public static final RegistryObject<BlockEntityType<?>> FILING_CABINET = register("filing_cabinet", ParadoxModBlocks.FILING_CABINET, FilingCabinetBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
