
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.paradox.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import net.mcreator.paradox.ParadoxMod;

public class ParadoxModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, ParadoxMod.MODID);
	public static final RegistryObject<SimpleParticleType> LASER = REGISTRY.register("laser", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> ELECTRICITY = REGISTRY.register("electricity", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> ELECTRICITY_2 = REGISTRY.register("electricity_2", () -> new SimpleParticleType(false));
}
