package net.mcreator.paradox.init;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.ModelLayerLocation;

public class ParadoxModLayerDefinitions {
	public static final ModelLayerLocation HELICOPTER_HAT = new ModelLayerLocation(new ResourceLocation("paradox", "helicopter_hat"), "helicopter_hat");
	public static final ModelLayerLocation JETPACK = new ModelLayerLocation(new ResourceLocation("paradox", "jetpack"), "jetpack");
}
