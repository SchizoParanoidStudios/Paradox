package net.mcreator.paradox.init;

import top.theillusivec4.curios.api.client.CuriosRendererRegistry;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;

import net.mcreator.paradox.client.renderer.JetpackRenderer;
import net.mcreator.paradox.client.renderer.HelicopterHatRenderer;
import net.mcreator.paradox.client.model.Modelmochilajet;
import net.mcreator.paradox.client.model.Modelgorro_mecanicoja;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ParadoxModCuriosRenderers {
	@SubscribeEvent
	public static void registerLayers(final EntityRenderersEvent.RegisterLayerDefinitions evt) {
		evt.registerLayerDefinition(ParadoxModLayerDefinitions.HELICOPTER_HAT, Modelgorro_mecanicoja::createBodyLayer);
		evt.registerLayerDefinition(ParadoxModLayerDefinitions.JETPACK, Modelmochilajet::createBodyLayer);
	}

	@SubscribeEvent
	public static void clientSetup(final FMLClientSetupEvent evt) {
		CuriosRendererRegistry.register(ParadoxModItems.HELICOPTER_HAT.get(), HelicopterHatRenderer::new);
		CuriosRendererRegistry.register(ParadoxModItems.JETPACK.get(), JetpackRenderer::new);
	}
}
