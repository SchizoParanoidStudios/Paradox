
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.paradox.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.paradox.entity.WorkerEntity;
import net.mcreator.paradox.entity.WispEntity;
import net.mcreator.paradox.entity.ToxicologistEntity;
import net.mcreator.paradox.entity.ToxicBombProjectileEntity;
import net.mcreator.paradox.entity.TimedBombProjectileEntity;
import net.mcreator.paradox.entity.TimeBombEntityEntity;
import net.mcreator.paradox.entity.TheLastInventor0Entity;
import net.mcreator.paradox.entity.SuitEntity;
import net.mcreator.paradox.entity.Strongman0Entity;
import net.mcreator.paradox.entity.ShockBombProjectileEntity;
import net.mcreator.paradox.entity.ParadoxBossEntity;
import net.mcreator.paradox.entity.NailProjectileEntity;
import net.mcreator.paradox.entity.MutantBacterieEntity;
import net.mcreator.paradox.entity.LaserProjectileEntity;
import net.mcreator.paradox.entity.InspectorEntity;
import net.mcreator.paradox.entity.Incursor0Entity;
import net.mcreator.paradox.entity.GrenadeprojectileEntity;
import net.mcreator.paradox.entity.ForemanEntity;
import net.mcreator.paradox.entity.ExplorerEntity;
import net.mcreator.paradox.entity.ElectricEntity;
import net.mcreator.paradox.entity.Electric4Entity;
import net.mcreator.paradox.entity.Electric2Entity;
import net.mcreator.paradox.entity.DinamiteProjectileEntity;
import net.mcreator.paradox.entity.CockroachEntity;
import net.mcreator.paradox.entity.CiborgFihEntity;
import net.mcreator.paradox.entity.AtrocityEntity;
import net.mcreator.paradox.entity.AirEntity;
import net.mcreator.paradox.entity.AbominationEntity;
import net.mcreator.paradox.ParadoxMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ParadoxModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ParadoxMod.MODID);
	public static final RegistryObject<EntityType<WorkerEntity>> WORKER = register("worker",
			EntityType.Builder.<WorkerEntity>of(WorkerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(WorkerEntity::new)

					.sized(0.6f, 2f));
	public static final RegistryObject<EntityType<NailProjectileEntity>> NAIL_PROJECTILE = register("nail_projectile",
			EntityType.Builder.<NailProjectileEntity>of(NailProjectileEntity::new, MobCategory.MISC).setCustomClientFactory(NailProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.3f, 0.3f));
	public static final RegistryObject<EntityType<ForemanEntity>> FOREMAN = register("foreman",
			EntityType.Builder.<ForemanEntity>of(ForemanEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ForemanEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<AtrocityEntity>> ATROCITY = register("atrocity",
			EntityType.Builder.<AtrocityEntity>of(AtrocityEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(AtrocityEntity::new)

					.sized(1f, 1.3f));
	public static final RegistryObject<EntityType<DinamiteProjectileEntity>> DINAMITE_PROJECTILE = register("dinamite_projectile", EntityType.Builder.<DinamiteProjectileEntity>of(DinamiteProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(DinamiteProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.4f, 0.4f));
	public static final RegistryObject<EntityType<MutantBacterieEntity>> MUTANT_BACTERIE = register("mutant_bacterie",
			EntityType.Builder.<MutantBacterieEntity>of(MutantBacterieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(MutantBacterieEntity::new)

					.sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<ExplorerEntity>> EXPLORER = register("explorer",
			EntityType.Builder.<ExplorerEntity>of(ExplorerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ExplorerEntity::new)

					.sized(0.8f, 0.9f));
	public static final RegistryObject<EntityType<CockroachEntity>> COCKROACH = register("cockroach",
			EntityType.Builder.<CockroachEntity>of(CockroachEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(CockroachEntity::new).fireImmune().sized(1f, 0.4f));
	public static final RegistryObject<EntityType<ShockBombProjectileEntity>> SHOCK_BOMB_PROJECTILE = register("shock_bomb_projectile", EntityType.Builder.<ShockBombProjectileEntity>of(ShockBombProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(ShockBombProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.3f, 0.3f));
	public static final RegistryObject<EntityType<GrenadeprojectileEntity>> GRENADEPROJECTILE = register("grenadeprojectile", EntityType.Builder.<GrenadeprojectileEntity>of(GrenadeprojectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(GrenadeprojectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<TimeBombEntityEntity>> TIME_BOMB_ENTITY = register("time_bomb_entity", EntityType.Builder.<TimeBombEntityEntity>of(TimeBombEntityEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TimeBombEntityEntity::new).fireImmune().sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<ElectricEntity>> ELECTRIC = register("electric",
			EntityType.Builder.<ElectricEntity>of(ElectricEntity::new, MobCategory.MISC).setCustomClientFactory(ElectricEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.3f, 0.3f));
	public static final RegistryObject<EntityType<LaserProjectileEntity>> LASER_PROJECTILE = register("laser_projectile", EntityType.Builder.<LaserProjectileEntity>of(LaserProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(LaserProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<Electric2Entity>> ELECTRIC_2 = register("electric_2",
			EntityType.Builder.<Electric2Entity>of(Electric2Entity::new, MobCategory.MISC).setCustomClientFactory(Electric2Entity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.3f, 0.3f));
	public static final RegistryObject<EntityType<TimedBombProjectileEntity>> TIMED_BOMB_PROJECTILE = register("timed_bomb_projectile", EntityType.Builder.<TimedBombProjectileEntity>of(TimedBombProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(TimedBombProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<ToxicologistEntity>> TOXICOLOGIST = register("toxicologist", EntityType.Builder.<ToxicologistEntity>of(ToxicologistEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ToxicologistEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<ToxicBombProjectileEntity>> TOXIC_BOMB_PROJECTILE = register("toxic_bomb_projectile", EntityType.Builder.<ToxicBombProjectileEntity>of(ToxicBombProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(ToxicBombProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.3f, 0.3f));
	public static final RegistryObject<EntityType<AirEntity>> AIR = register("air",
			EntityType.Builder.<AirEntity>of(AirEntity::new, MobCategory.MISC).setCustomClientFactory(AirEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<CiborgFihEntity>> CIBORG_FIH = register("ciborg_fih",
			EntityType.Builder.<CiborgFihEntity>of(CiborgFihEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(CiborgFihEntity::new)

					.sized(0.6f, 1.1f));
	public static final RegistryObject<EntityType<TheLastInventor0Entity>> THE_LAST_INVENTOR_0 = register("the_last_inventor_0",
			EntityType.Builder.<TheLastInventor0Entity>of(TheLastInventor0Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TheLastInventor0Entity::new)

					.sized(1f, 3.2f));
	public static final RegistryObject<EntityType<AbominationEntity>> ABOMINATION = register("abomination",
			EntityType.Builder.<AbominationEntity>of(AbominationEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(AbominationEntity::new)

					.sized(1.2f, 2.5f));
	public static final RegistryObject<EntityType<Strongman0Entity>> STRONGMAN_0 = register("strongman_0",
			EntityType.Builder.<Strongman0Entity>of(Strongman0Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(Strongman0Entity::new)

					.sized(1f, 2.1f));
	public static final RegistryObject<EntityType<ParadoxBossEntity>> PARADOX_BOSS = register("paradox_boss",
			EntityType.Builder.<ParadoxBossEntity>of(ParadoxBossEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ParadoxBossEntity::new)

					.sized(2f, 2f));
	public static final RegistryObject<EntityType<WispEntity>> WISP = register("wisp",
			EntityType.Builder.<WispEntity>of(WispEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(WispEntity::new).fireImmune().sized(0.2f, 0.2f));
	public static final RegistryObject<EntityType<SuitEntity>> SUIT = register("suit",
			EntityType.Builder.<SuitEntity>of(SuitEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SuitEntity::new).fireImmune().sized(0.1f, 1.7f));
	public static final RegistryObject<EntityType<InspectorEntity>> INSPECTOR = register("inspector",
			EntityType.Builder.<InspectorEntity>of(InspectorEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(InspectorEntity::new)

					.sized(0.7f, 2.2f));
	public static final RegistryObject<EntityType<Electric4Entity>> ELECTRIC_4 = register("electric_4",
			EntityType.Builder.<Electric4Entity>of(Electric4Entity::new, MobCategory.MISC).setCustomClientFactory(Electric4Entity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<Incursor0Entity>> INCURSOR_0 = register("incursor_0",
			EntityType.Builder.<Incursor0Entity>of(Incursor0Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(Incursor0Entity::new)

					.sized(0.6f, 2.2f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			WorkerEntity.init();
			ForemanEntity.init();
			AtrocityEntity.init();
			MutantBacterieEntity.init();
			ExplorerEntity.init();
			CockroachEntity.init();
			TimeBombEntityEntity.init();
			ToxicologistEntity.init();
			CiborgFihEntity.init();
			TheLastInventor0Entity.init();
			AbominationEntity.init();
			Strongman0Entity.init();
			ParadoxBossEntity.init();
			WispEntity.init();
			SuitEntity.init();
			InspectorEntity.init();
			Incursor0Entity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(WORKER.get(), WorkerEntity.createAttributes().build());
		event.put(FOREMAN.get(), ForemanEntity.createAttributes().build());
		event.put(ATROCITY.get(), AtrocityEntity.createAttributes().build());
		event.put(MUTANT_BACTERIE.get(), MutantBacterieEntity.createAttributes().build());
		event.put(EXPLORER.get(), ExplorerEntity.createAttributes().build());
		event.put(COCKROACH.get(), CockroachEntity.createAttributes().build());
		event.put(TIME_BOMB_ENTITY.get(), TimeBombEntityEntity.createAttributes().build());
		event.put(TOXICOLOGIST.get(), ToxicologistEntity.createAttributes().build());
		event.put(CIBORG_FIH.get(), CiborgFihEntity.createAttributes().build());
		event.put(THE_LAST_INVENTOR_0.get(), TheLastInventor0Entity.createAttributes().build());
		event.put(ABOMINATION.get(), AbominationEntity.createAttributes().build());
		event.put(STRONGMAN_0.get(), Strongman0Entity.createAttributes().build());
		event.put(PARADOX_BOSS.get(), ParadoxBossEntity.createAttributes().build());
		event.put(WISP.get(), WispEntity.createAttributes().build());
		event.put(SUIT.get(), SuitEntity.createAttributes().build());
		event.put(INSPECTOR.get(), InspectorEntity.createAttributes().build());
		event.put(INCURSOR_0.get(), Incursor0Entity.createAttributes().build());
	}
}
