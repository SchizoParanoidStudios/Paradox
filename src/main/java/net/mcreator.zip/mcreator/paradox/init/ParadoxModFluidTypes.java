
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.paradox.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.paradox.fluid.types.StillWaterFluidType;
import net.mcreator.paradox.fluid.types.HotWaterFluidType;
import net.mcreator.paradox.fluid.types.ContaminatedWaterFluidType;
import net.mcreator.paradox.fluid.types.AcidFluidType;
import net.mcreator.paradox.ParadoxMod;

public class ParadoxModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, ParadoxMod.MODID);
	public static final RegistryObject<FluidType> CONTAMINATED_WATER_TYPE = REGISTRY.register("contaminated_water", () -> new ContaminatedWaterFluidType());
	public static final RegistryObject<FluidType> STILL_WATER_TYPE = REGISTRY.register("still_water", () -> new StillWaterFluidType());
	public static final RegistryObject<FluidType> HOT_WATER_TYPE = REGISTRY.register("hot_water", () -> new HotWaterFluidType());
	public static final RegistryObject<FluidType> ACID_TYPE = REGISTRY.register("acid", () -> new AcidFluidType());
}
