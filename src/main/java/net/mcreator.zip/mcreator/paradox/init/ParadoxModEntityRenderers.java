
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.paradox.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.paradox.client.renderer.WorkerRenderer;
import net.mcreator.paradox.client.renderer.WispRenderer;
import net.mcreator.paradox.client.renderer.ToxicologistRenderer;
import net.mcreator.paradox.client.renderer.TimeBombEntityRenderer;
import net.mcreator.paradox.client.renderer.TheLastInventor0Renderer;
import net.mcreator.paradox.client.renderer.SuitRenderer;
import net.mcreator.paradox.client.renderer.Strongman0Renderer;
import net.mcreator.paradox.client.renderer.ParadoxBossRenderer;
import net.mcreator.paradox.client.renderer.NailProjectileRenderer;
import net.mcreator.paradox.client.renderer.MutantBacterieRenderer;
import net.mcreator.paradox.client.renderer.InspectorRenderer;
import net.mcreator.paradox.client.renderer.Incursor0Renderer;
import net.mcreator.paradox.client.renderer.ForemanRenderer;
import net.mcreator.paradox.client.renderer.ExplorerRenderer;
import net.mcreator.paradox.client.renderer.CockroachRenderer;
import net.mcreator.paradox.client.renderer.CiborgFihRenderer;
import net.mcreator.paradox.client.renderer.AtrocityRenderer;
import net.mcreator.paradox.client.renderer.AbominationRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ParadoxModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(ParadoxModEntities.WORKER.get(), WorkerRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.NAIL_PROJECTILE.get(), NailProjectileRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.FOREMAN.get(), ForemanRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.ATROCITY.get(), AtrocityRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.DINAMITE_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.MUTANT_BACTERIE.get(), MutantBacterieRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.EXPLORER.get(), ExplorerRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.COCKROACH.get(), CockroachRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.SHOCK_BOMB_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.GRENADEPROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.TIME_BOMB_ENTITY.get(), TimeBombEntityRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.ELECTRIC.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.LASER_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.ELECTRIC_2.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.TIMED_BOMB_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.TOXICOLOGIST.get(), ToxicologistRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.TOXIC_BOMB_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.AIR.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.CIBORG_FIH.get(), CiborgFihRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.THE_LAST_INVENTOR_0.get(), TheLastInventor0Renderer::new);
		event.registerEntityRenderer(ParadoxModEntities.ABOMINATION.get(), AbominationRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.STRONGMAN_0.get(), Strongman0Renderer::new);
		event.registerEntityRenderer(ParadoxModEntities.PARADOX_BOSS.get(), ParadoxBossRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.WISP.get(), WispRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.SUIT.get(), SuitRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.INSPECTOR.get(), InspectorRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.ELECTRIC_4.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ParadoxModEntities.INCURSOR_0.get(), Incursor0Renderer::new);
	}
}
