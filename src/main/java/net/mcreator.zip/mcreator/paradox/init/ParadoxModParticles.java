
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.paradox.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.paradox.client.particle.LaserParticle;
import net.mcreator.paradox.client.particle.ElectricityParticle;
import net.mcreator.paradox.client.particle.Electricity2Particle;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ParadoxModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(ParadoxModParticleTypes.LASER.get(), LaserParticle::provider);
		event.registerSpriteSet(ParadoxModParticleTypes.ELECTRICITY.get(), ElectricityParticle::provider);
		event.registerSpriteSet(ParadoxModParticleTypes.ELECTRICITY_2.get(), Electricity2Particle::provider);
	}
}
