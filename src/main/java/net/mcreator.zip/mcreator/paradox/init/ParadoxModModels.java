
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.paradox.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.paradox.client.model.Modelmochilajet;
import net.mcreator.paradox.client.model.Modelgorro_mecanicoja;
import net.mcreator.paradox.client.model.Modelcapitas;
import net.mcreator.paradox.client.model.Modelbrillo;
import net.mcreator.paradox.client.model.Modelbrasos;
import net.mcreator.paradox.client.model.Modelbicho;
import net.mcreator.paradox.client.model.Modelarroww;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class ParadoxModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelcapitas.LAYER_LOCATION, Modelcapitas::createBodyLayer);
		event.registerLayerDefinition(Modelbicho.LAYER_LOCATION, Modelbicho::createBodyLayer);
		event.registerLayerDefinition(Modelbrillo.LAYER_LOCATION, Modelbrillo::createBodyLayer);
		event.registerLayerDefinition(Modelarroww.LAYER_LOCATION, Modelarroww::createBodyLayer);
		event.registerLayerDefinition(Modelbrasos.LAYER_LOCATION, Modelbrasos::createBodyLayer);
		event.registerLayerDefinition(Modelgorro_mecanicoja.LAYER_LOCATION, Modelgorro_mecanicoja::createBodyLayer);
		event.registerLayerDefinition(Modelmochilajet.LAYER_LOCATION, Modelmochilajet::createBodyLayer);
	}
}
