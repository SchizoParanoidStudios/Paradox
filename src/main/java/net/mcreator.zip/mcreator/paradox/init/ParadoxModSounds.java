
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.paradox.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.ParadoxMod;

public class ParadoxModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ParadoxMod.MODID);
	public static final RegistryObject<SoundEvent> SHOT = REGISTRY.register("shot", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "shot")));
	public static final RegistryObject<SoundEvent> SAW1 = REGISTRY.register("saw1", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "saw1")));
	public static final RegistryObject<SoundEvent> SAW2 = REGISTRY.register("saw2", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "saw2")));
	public static final RegistryObject<SoundEvent> GEARS_AMBIENT = REGISTRY.register("gears_ambient", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "gears_ambient")));
	public static final RegistryObject<SoundEvent> LASER = REGISTRY.register("laser", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "laser")));
	public static final RegistryObject<SoundEvent> DEATRAY = REGISTRY.register("deatray", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "deatray")));
	public static final RegistryObject<SoundEvent> ELECTRICGUN = REGISTRY.register("electricgun", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "electricgun")));
	public static final RegistryObject<SoundEvent> TESLAGUN = REGISTRY.register("teslagun", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "teslagun")));
	public static final RegistryObject<SoundEvent> STRONGMAN_HURT = REGISTRY.register("strongman_hurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "strongman_hurt")));
	public static final RegistryObject<SoundEvent> ATROCITY_ATAK = REGISTRY.register("atrocity_atak", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "atrocity_atak")));
	public static final RegistryObject<SoundEvent> ATROCITY_HURT = REGISTRY.register("atrocity_hurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "atrocity_hurt")));
	public static final RegistryObject<SoundEvent> ATTROCITY_HURT2 = REGISTRY.register("attrocity_hurt2", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "attrocity_hurt2")));
	public static final RegistryObject<SoundEvent> ATROCITY_VOICE2 = REGISTRY.register("atrocity_voice2", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "atrocity_voice2")));
	public static final RegistryObject<SoundEvent> ATRCOITY_VOICE_1 = REGISTRY.register("atrcoity_voice_1", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "atrcoity_voice_1")));
	public static final RegistryObject<SoundEvent> HELI_SOUND1 = REGISTRY.register("heli_sound1", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "heli_sound1")));
	public static final RegistryObject<SoundEvent> HELI_SOUND2 = REGISTRY.register("heli_sound2", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "heli_sound2")));
	public static final RegistryObject<SoundEvent> HELI_HURT = REGISTRY.register("heli_hurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "heli_hurt")));
	public static final RegistryObject<SoundEvent> HELI_VOICE = REGISTRY.register("heli_voice", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "heli_voice")));
	public static final RegistryObject<SoundEvent> INVENTOR_HURT2 = REGISTRY.register("inventor_hurt2", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "inventor_hurt2")));
	public static final RegistryObject<SoundEvent> INVENTOR_HURT = REGISTRY.register("inventor_hurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "inventor_hurt")));
	public static final RegistryObject<SoundEvent> INVENTOR_VOICE1 = REGISTRY.register("inventor_voice1", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "inventor_voice1")));
	public static final RegistryObject<SoundEvent> INSPECTOR_VOICE1 = REGISTRY.register("inspector_voice1", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "inspector_voice1")));
	public static final RegistryObject<SoundEvent> INSPECTRO_VOICE = REGISTRY.register("inspectro_voice", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "inspectro_voice")));
	public static final RegistryObject<SoundEvent> INVENTOR_VOICE2 = REGISTRY.register("inventor_voice2", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "inventor_voice2")));
	public static final RegistryObject<SoundEvent> INVENTOR_VOICE3 = REGISTRY.register("inventor_voice3", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "inventor_voice3")));
	public static final RegistryObject<SoundEvent> INVENTOR_HURT3 = REGISTRY.register("inventor_hurt3", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "inventor_hurt3")));
	public static final RegistryObject<SoundEvent> STRONGMAN_HURT2 = REGISTRY.register("strongman_hurt2", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "strongman_hurt2")));
	public static final RegistryObject<SoundEvent> STRONGMAN_VOICE1 = REGISTRY.register("strongman_voice1", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "strongman_voice1")));
	public static final RegistryObject<SoundEvent> STRONGMAN_VOICE2 = REGISTRY.register("strongman_voice2", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "strongman_voice2")));
	public static final RegistryObject<SoundEvent> STRONGMAN_VOICE3 = REGISTRY.register("strongman_voice3", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "strongman_voice3")));
	public static final RegistryObject<SoundEvent> TOXIC_IDLE = REGISTRY.register("toxic_idle", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "toxic_idle")));
	public static final RegistryObject<SoundEvent> TOXIC_VOICE2 = REGISTRY.register("toxic_voice2", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "toxic_voice2")));
	public static final RegistryObject<SoundEvent> TOXIC_HURT = REGISTRY.register("toxic_hurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "toxic_hurt")));
	public static final RegistryObject<SoundEvent> WELDER_VOICE = REGISTRY.register("welder_voice", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "welder_voice")));
	public static final RegistryObject<SoundEvent> WELDER_HURT = REGISTRY.register("welder_hurt", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "welder_hurt")));
	public static final RegistryObject<SoundEvent> WORKER_AGRESSION = REGISTRY.register("worker_agression", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "worker_agression")));
	public static final RegistryObject<SoundEvent> WORKER_IDLE2 = REGISTRY.register("worker_idle2", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "worker_idle2")));
	public static final RegistryObject<SoundEvent> WORKER_IDLE3 = REGISTRY.register("worker_idle3", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "worker_idle3")));
	public static final RegistryObject<SoundEvent> WORKER_HURT1 = REGISTRY.register("worker_hurt1", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "worker_hurt1")));
	public static final RegistryObject<SoundEvent> WORKER_HURT2 = REGISTRY.register("worker_hurt2", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "worker_hurt2")));
	public static final RegistryObject<SoundEvent> PARADOX = REGISTRY.register("paradox", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "paradox")));
	public static final RegistryObject<SoundEvent> NOISE = REGISTRY.register("noise", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "noise")));
	public static final RegistryObject<SoundEvent> INDUSTRIAL = REGISTRY.register("industrial", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("paradox", "industrial")));
}
