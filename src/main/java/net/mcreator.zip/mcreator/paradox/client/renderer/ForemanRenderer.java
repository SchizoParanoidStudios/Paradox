
package net.mcreator.paradox.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.paradox.entity.ForemanEntity;
import net.mcreator.paradox.client.model.Modelcapitas;

public class ForemanRenderer extends MobRenderer<ForemanEntity, Modelcapitas<ForemanEntity>> {
	public ForemanRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelcapitas<ForemanEntity>(context.bakeLayer(Modelcapitas.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(ForemanEntity entity) {
		return new ResourceLocation("paradox:textures/entities/mecanik.png");
	}
}
