package net.mcreator.paradox.item.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.item.LaserBeamItem;

public class LaserBeamItemModel extends GeoModel<LaserBeamItem> {
	@Override
	public ResourceLocation getAnimationResource(LaserBeamItem animatable) {
		return new ResourceLocation("paradox", "animations/laserfinal.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(LaserBeamItem animatable) {
		return new ResourceLocation("paradox", "geo/laserfinal.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(LaserBeamItem animatable) {
		return new ResourceLocation("paradox", "textures/item/ecopetaaaa.png");
	}
}
