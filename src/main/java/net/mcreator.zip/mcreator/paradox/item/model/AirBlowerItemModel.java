package net.mcreator.paradox.item.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.item.AirBlowerItem;

public class AirBlowerItemModel extends GeoModel<AirBlowerItem> {
	@Override
	public ResourceLocation getAnimationResource(AirBlowerItem animatable) {
		return new ResourceLocation("paradox", "animations/blower.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(AirBlowerItem animatable) {
		return new ResourceLocation("paradox", "geo/blower.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(AirBlowerItem animatable) {
		return new ResourceLocation("paradox", "textures/item/soplador.png");
	}
}
