package net.mcreator.paradox.item.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.item.NailMachinegunItem;

public class NailMachinegunItemModel extends GeoModel<NailMachinegunItem> {
	@Override
	public ResourceLocation getAnimationResource(NailMachinegunItem animatable) {
		return new ResourceLocation("paradox", "animations/asaltador.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(NailMachinegunItem animatable) {
		return new ResourceLocation("paradox", "geo/asaltador.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(NailMachinegunItem animatable) {
		return new ResourceLocation("paradox", "textures/item/gunee.png");
	}
}
