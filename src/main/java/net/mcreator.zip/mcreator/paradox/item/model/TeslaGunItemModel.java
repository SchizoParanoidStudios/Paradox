package net.mcreator.paradox.item.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.item.TeslaGunItem;

public class TeslaGunItemModel extends GeoModel<TeslaGunItem> {
	@Override
	public ResourceLocation getAnimationResource(TeslaGunItem animatable) {
		return new ResourceLocation("paradox", "animations/rayoele.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(TeslaGunItem animatable) {
		return new ResourceLocation("paradox", "geo/rayoele.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(TeslaGunItem animatable) {
		return new ResourceLocation("paradox", "textures/item/armaa.png");
	}
}
