
package net.mcreator.paradox.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.paradox.init.ParadoxModFluids;

public class StillWaterItem extends BucketItem {
	public StillWaterItem() {
		super(ParadoxModFluids.STILL_WATER, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.COMMON));
	}
}
