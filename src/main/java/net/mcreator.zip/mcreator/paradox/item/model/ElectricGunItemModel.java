package net.mcreator.paradox.item.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.item.ElectricGunItem;

public class ElectricGunItemModel extends GeoModel<ElectricGunItem> {
	@Override
	public ResourceLocation getAnimationResource(ElectricGunItem animatable) {
		return new ResourceLocation("paradox", "animations/teslagun.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(ElectricGunItem animatable) {
		return new ResourceLocation("paradox", "geo/teslagun.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(ElectricGunItem animatable) {
		return new ResourceLocation("paradox", "textures/item/vara.png");
	}
}
