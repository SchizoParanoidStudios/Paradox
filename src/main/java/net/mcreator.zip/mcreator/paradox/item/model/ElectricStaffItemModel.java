package net.mcreator.paradox.item.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.item.ElectricStaffItem;

public class ElectricStaffItemModel extends GeoModel<ElectricStaffItem> {
	@Override
	public ResourceLocation getAnimationResource(ElectricStaffItem animatable) {
		return new ResourceLocation("paradox", "animations/varaelectrica.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(ElectricStaffItem animatable) {
		return new ResourceLocation("paradox", "geo/varaelectrica.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(ElectricStaffItem animatable) {
		return new ResourceLocation("paradox", "textures/item/vara.png");
	}
}
