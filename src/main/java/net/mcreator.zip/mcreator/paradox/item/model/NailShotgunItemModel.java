package net.mcreator.paradox.item.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.item.NailShotgunItem;

public class NailShotgunItemModel extends GeoModel<NailShotgunItem> {
	@Override
	public ResourceLocation getAnimationResource(NailShotgunItem animatable) {
		return new ResourceLocation("paradox", "animations/shotgan.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(NailShotgunItem animatable) {
		return new ResourceLocation("paradox", "geo/shotgan.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(NailShotgunItem animatable) {
		return new ResourceLocation("paradox", "textures/item/ecopeta.png");
	}
}
