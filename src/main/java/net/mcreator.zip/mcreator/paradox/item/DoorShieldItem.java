
package net.mcreator.paradox.item;

import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.Item;

public class DoorShieldItem extends ShieldItem {
	public DoorShieldItem() {
		super(new Item.Properties().durability(20));
	}
}
