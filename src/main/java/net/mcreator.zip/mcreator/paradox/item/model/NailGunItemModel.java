package net.mcreator.paradox.item.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.item.NailGunItem;

public class NailGunItemModel extends GeoModel<NailGunItem> {
	@Override
	public ResourceLocation getAnimationResource(NailGunItem animatable) {
		return new ResourceLocation("paradox", "animations/nailgun.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(NailGunItem animatable) {
		return new ResourceLocation("paradox", "geo/nailgun.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(NailGunItem animatable) {
		return new ResourceLocation("paradox", "textures/item/grapadora.png");
	}
}
