package net.mcreator.paradox.item.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.item.ElectricSawItem;

public class ElectricSawItemModel extends GeoModel<ElectricSawItem> {
	@Override
	public ResourceLocation getAnimationResource(ElectricSawItem animatable) {
		return new ResourceLocation("paradox", "animations/sidae.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(ElectricSawItem animatable) {
		return new ResourceLocation("paradox", "geo/sidae.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(ElectricSawItem animatable) {
		return new ResourceLocation("paradox", "textures/item/e.png");
	}
}
