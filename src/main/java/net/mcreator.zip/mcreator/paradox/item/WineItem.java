
package net.mcreator.paradox.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.network.chat.Component;

import net.mcreator.paradox.procedures.WinePlayerFinishesUsingItemProcedure;

import java.util.List;

public class WineItem extends Item {
	public WineItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.COMMON).food((new FoodProperties.Builder()).nutrition(0).saturationMod(0.7f).alwaysEat().build()));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("item.paradox.wine.description_0"));
		list.add(Component.translatable("item.paradox.wine.description_1"));
		list.add(Component.translatable("item.paradox.wine.description_2"));
		list.add(Component.translatable("item.paradox.wine.description_3"));
		list.add(Component.translatable("item.paradox.wine.description_4"));
	}

	@Override
	public ItemStack finishUsingItem(ItemStack itemstack, Level world, LivingEntity entity) {
		ItemStack retval = super.finishUsingItem(itemstack, world, entity);
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		WinePlayerFinishesUsingItemProcedure.execute(world, entity);
		return retval;
	}
}
