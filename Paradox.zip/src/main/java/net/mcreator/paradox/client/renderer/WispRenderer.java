
package net.mcreator.paradox.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.paradox.entity.WispEntity;
import net.mcreator.paradox.client.model.Modelbrillo;

public class WispRenderer extends MobRenderer<WispEntity, Modelbrillo<WispEntity>> {
	public WispRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelbrillo<WispEntity>(context.bakeLayer(Modelbrillo.LAYER_LOCATION)), 0f);
	}

	@Override
	public ResourceLocation getTextureLocation(WispEntity entity) {
		return new ResourceLocation("paradox:textures/entities/brillo.png");
	}
}
