
package net.mcreator.paradox.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.paradox.entity.CockroachEntity;
import net.mcreator.paradox.client.model.Modelbicho;

public class CockroachRenderer extends MobRenderer<CockroachEntity, Modelbicho<CockroachEntity>> {
	public CockroachRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelbicho<CockroachEntity>(context.bakeLayer(Modelbicho.LAYER_LOCATION)), 0f);
	}

	@Override
	public ResourceLocation getTextureLocation(CockroachEntity entity) {
		return new ResourceLocation("paradox:textures/entities/cuacurahca.png");
	}
}
