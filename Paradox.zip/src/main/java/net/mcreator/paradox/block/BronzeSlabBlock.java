
package net.mcreator.paradox.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.SlabBlock;

public class BronzeSlabBlock extends SlabBlock {
	public BronzeSlabBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.COPPER).strength(3f, 15f).requiresCorrectToolForDrops());
	}
}
