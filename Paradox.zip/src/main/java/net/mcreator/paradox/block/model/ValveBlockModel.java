package net.mcreator.paradox.block.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.paradox.block.entity.ValveTileEntity;

public class ValveBlockModel extends GeoModel<ValveTileEntity> {
	@Override
	public ResourceLocation getAnimationResource(ValveTileEntity animatable) {
		return new ResourceLocation("paradox", "animations/valvulaanimada.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(ValveTileEntity animatable) {
		return new ResourceLocation("paradox", "geo/valvulaanimada.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(ValveTileEntity animatable) {
		return new ResourceLocation("paradox", "textures/block/puertaproo.png");
	}
}
