
package net.mcreator.paradox.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.IronBarsBlock;

public class BronzeReinforcedGlassBlock extends IronBarsBlock {
	public BronzeReinforcedGlassBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.COPPER).strength(2f, 15f).requiresCorrectToolForDrops().noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
	}
}
