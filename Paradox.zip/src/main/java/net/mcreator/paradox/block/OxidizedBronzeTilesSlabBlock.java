
package net.mcreator.paradox.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.SlabBlock;

public class OxidizedBronzeTilesSlabBlock extends SlabBlock {
	public OxidizedBronzeTilesSlabBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.COPPER).strength(4f, 15f).requiresCorrectToolForDrops());
	}
}
