
package net.mcreator.paradox.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.entity.player.Player;
import net.minecraft.util.RandomSource;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.client.Minecraft;

import net.mcreator.paradox.procedures.WallLigthOnRandomClientDisplayTickProcedure;

public class WallLigthBlock extends Block {
	public static final DirectionProperty FACING = DirectionalBlock.FACING;

	public WallLigthBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.COPPER).strength(2f, 5f).lightLevel(s -> 10).requiresCorrectToolForDrops().noOcclusion().randomTicks().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(3, 3, 0, 13, 13, 2), box(6, 6, 2, 10, 10, 4), box(4.7, 4.7, 1.7, 11.3, 11.3, 5.3));
			case NORTH -> Shapes.or(box(3, 3, 14, 13, 13, 16), box(6, 6, 12, 10, 10, 14), box(4.7, 4.7, 10.7, 11.3, 11.3, 14.3));
			case EAST -> Shapes.or(box(0, 3, 3, 2, 13, 13), box(2, 6, 6, 4, 10, 10), box(1.7, 4.7, 4.7, 5.3, 11.3, 11.3));
			case WEST -> Shapes.or(box(14, 3, 3, 16, 13, 13), box(12, 6, 6, 14, 10, 10), box(10.7, 4.7, 4.7, 14.3, 11.3, 11.3));
			case UP -> Shapes.or(box(3, 0, 3, 13, 2, 13), box(6, 2, 6, 10, 4, 10), box(4.7, 1.7, 4.7, 11.3, 5.3, 11.3));
			case DOWN -> Shapes.or(box(3, 14, 3, 13, 16, 13), box(6, 12, 6, 10, 14, 10), box(4.7, 10.7, 4.7, 11.3, 14.3, 11.3));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(FACING, context.getNearestLookingDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@OnlyIn(Dist.CLIENT)
	@Override
	public void animateTick(BlockState blockstate, Level world, BlockPos pos, RandomSource random) {
		super.animateTick(blockstate, world, pos, random);
		Player entity = Minecraft.getInstance().player;
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		WallLigthOnRandomClientDisplayTickProcedure.execute(world, x, y, z);
	}
}
